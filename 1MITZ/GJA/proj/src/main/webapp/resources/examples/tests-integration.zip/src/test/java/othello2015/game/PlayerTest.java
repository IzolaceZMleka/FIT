package othello2015.game;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PlayerTest {
    public Player player;

    @Before
    public void initPlayer() {
        player = new Player(true);
    }

    @Test
    public void emptyPool() {
        assertTrue("Test prazdne sady kamenu.", player.emptyPool());
    }

    @Test
    public void isWhite() {
        assertTrue(player.isWhite());
    }

   @Test
    public void textRepresentation() {
        assertEquals("Test spravne textove reprezentace objektu.", "hrac:white", "hrac:" + player);
        Player black = new Player(false);
        assertEquals("Test spravne textove reprezentace objektu.", "hrac:black", "hrac:" + black);
    }

}