package othello2015.game;

import org.junit.Before;
import org.junit.Test;
import othello2015.board.Board;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class GameTest {
    public Game game;

    @Before
    public void initGame() {
        Board board = mock(Board.class);
        game = new Game(board);
    }

    @Test
    public void addPlayer() {
        Player p1 = mock(Player.class);
        when(p1.isWhite()).thenReturn(true);
        Player p2 = mock(Player.class);
        when(p2.isWhite()).thenReturn(false);
        Player p3 = mock(Player.class);
        when(p3.isWhite()).thenReturn(true);

        assertTrue(game.addPlayer(p1));
        assertTrue(game.addPlayer(p2));
        assertFalse("Hraj je pouze pro dva hráče", game.addPlayer(p3));
    }

    @Test
    public void currentPlayer() {
        Player p1 = mock(Player.class);
        when(p1.isWhite()).thenReturn(true);
        Player p2 = mock(Player.class);
        when(p2.isWhite()).thenReturn(false);

        game.addPlayer(p1);
        game.addPlayer(p2);

        assertSame(p1,game.currentPlayer());
        game.nextPlayer();
        assertSame(p2,game.currentPlayer());
        game.nextPlayer();
        assertSame(p1,game.currentPlayer());
    }

}