package othello2015;

import org.junit.Before;
import org.junit.Test;
import othello2015.board.Board;
import othello2015.board.Field;
import othello2015.game.Player;
import othello2015.game.ReversiRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Testování propojení mezi třídami game.Player a board.Board
 */
public class ITPlayerBoardTest {
    public int size = 8;
    public Board board;

    @Before
    public void initBoard() {
        ReversiRules rules = new ReversiRules(size);
        board = new Board(rules);
    }

    @Test
    public void initPlayerOnBoard() {

        Player p1 = new Player(true);
        Player p2 = new Player(false);

        p1.init(board);
        p2.init(board);

        assertFalse("Test neprazdne sady kamenu.", p1.emptyPool());
        assertFalse("Test neprazdne sady kamenu.", p1.emptyPool());

        assertTrue("Test spravneho umisteni pocatecnich kamenu.",
                board.getField(4, 4).getDisk().isWhite());
        assertTrue("Test spravneho umisteni pocatecnich kamenu.",
                board.getField(5, 5).getDisk().isWhite());
        assertFalse("Test spravneho umisteni pocatecnich kamenu.",
                board.getField(4, 5).getDisk().isWhite());
        assertFalse("Test spravneho umisteni pocatecnich kamenu.",
                board.getField(5, 4).getDisk().isWhite());
    }

}