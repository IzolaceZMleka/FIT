package com.mycompany.app.dep01;

import org.junit.Rule;
import org.junit.Test;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import static org.junit.Assert.*;

public class ClovekTest {

    public ILogger getLoggerMock() {
        return mock(ILogger.class);
    }

    @Test
    public void pozdrav() {
        ILogger logger =  mock(ILogger.class);
        Clovek clovek = new Clovek(logger, "Karel Novak", 34, "Dobrý den");
        clovek.pozdrav();
        // ověřím zda metoda byla zavolána 1x a se stejným parametrem
        verify(logger, times(1)).log("byla zavolána metoda pozdrav");
    }

    @Test
    public void jsiPlnolety() {
        ILogger logger =  mock(ILogger.class);
        Clovek clovek = new Clovek(logger, "Karel Novak", 34, "Dobrý den");
        assertTrue(clovek.jsiPlnolety());
        // ověřím zda metoda nebyla vůbec volaná
        verify(logger, times(0)).log("");
    }

    @Test
    public void getJmeno() {
        ILogger logger =  mock(ILogger.class);
        Clovek clovek = new Clovek(logger, "Karel Novak", 34, "Dobrý den");
        assertEquals("Karel Novak", clovek.getJmeno());
        // ověřím zda metoda nebyla vůbec volaná
        verify(logger, times(0)).log("Změněn pozdrav z \"Dobrý den\" na \"Čau\"");
    }

    @Test
    public void setJmeno() {
        ILogger logger =  mock(ILogger.class);
        Clovek clovek = new Clovek(logger, "Karel Novak", 34, "Dobrý den");
        clovek.setJmeno("Pavel Novák");
        // ověřím zda metoda byla volaná 2x se stejnými parametry
        verify(logger, times(1)).log("Změněno jméno z \"Karel Novak\" na \"Pavel Novák\"");
    }

    @Test
    public void setPozdrav() {
        ILogger logger =  mock(ILogger.class);
        Clovek clovek = new Clovek(logger, "Karel Novak", 34, "Dobrý den");
        clovek.setPozdrav("Čau");
        clovek.pozdrav();
        // ověřím zda metoda byla volaná 2x se stejnými parametry
        verify(logger, times(1)).log("Změněn pozdrav z \"Dobrý den\" na \"Čau\"");
        verify(logger, times(1)).log("byla zavolána metoda pozdrav");
    }

}
