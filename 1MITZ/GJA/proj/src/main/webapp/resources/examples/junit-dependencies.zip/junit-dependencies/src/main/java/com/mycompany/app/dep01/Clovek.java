package com.mycompany.app.dep01;

public class Clovek {
    private ILogger logger;
    private String jmeno;
    private Integer vek = 0;
    private String pozdrav = "Ahoj";

    public Clovek(ILogger logger, String jmeno, Integer vek, String pozdrav) {
        this.logger = logger;
        this.jmeno = jmeno;
        this.vek = vek;
        this.pozdrav = pozdrav;
    }

    /**
     * Napíše svuj pozdrav
     */
    public void pozdrav() {
        logger.log("byla zavolána metoda pozdrav");
        System.out.println(pozdrav);
    }

    /**
     * Zjisti zda je plnolety
     *
     * @return TRUE pokud je plnoletý
     */
    public boolean jsiPlnolety() {
        return vek >= 18;
    }

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String jmeno) {
        logger.log("Změněno jméno z \"" + this.jmeno + "\" na \"" + jmeno + "\"");
        this.jmeno = jmeno;
    }

    public Integer getVek() {
        return vek;
    }

    public void setVek(Integer vek) {
        logger.log("Změněn věk z \"" + this.vek + "\" na \"" + vek + "\"");
        this.vek = vek;
    }

    public String getPozdrav() {
        return pozdrav;
    }

    public void setPozdrav(String pozdrav) {
        logger.log("Změněn pozdrav z \"" + this.pozdrav + "\" na \"" + pozdrav + "\"");
        this.pozdrav = pozdrav;
    }
}
