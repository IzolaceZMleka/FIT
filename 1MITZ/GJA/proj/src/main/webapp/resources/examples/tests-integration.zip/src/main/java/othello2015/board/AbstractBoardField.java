package othello2015.board;

/**
 * Disk na hracím poli
 */
public class AbstractBoardField implements Field
{

    private int row;
    private int col;

    private Disk disk = null;

    private Field[] around;

    public AbstractBoardField(int row, int col) {
        this.col = col;
        this.row = row;
        this.around = new Field[8];
    }

    public void addNextField(Field.Direction dirs, Field field) {
        int key = 0;
        for (Direction c : Direction.values()) {
            if (dirs == c) {
                break;
            }
            key++;
        }
        this.around[key] = field;
    }

    public Disk getDisk() {
        return disk;
    }

    public Field nextField(Field.Direction dirs) {
        int key = 0;
        for (Direction c : Direction.values()) {
            if (dirs == c) {
                break;
            }
            key++;
        }
        return around[key];
    }

    public boolean putDisk(Disk disk) {
        if (this.disk != null) {
            return false;
        } else {
            this.disk = disk;
            return true;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if ((obj != null) && (obj instanceof AbstractBoardField) && (this.getClass() == obj.getClass())) {
            final AbstractBoardField other = (AbstractBoardField) obj;
            if ((other.row == this.row) && (other.col == this.col)) {
                return true;
            }
        }
        return false;
    }

    public boolean canPutDisk(Disk disk) {
        return this.disk == null;
    }
}
