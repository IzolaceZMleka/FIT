package othello2015.game;

import othello2015.board.AbstractBoardField;

public class BoardField extends AbstractBoardField
{
    public BoardField(int row, int col) {
		super(row, col);
	}
}
