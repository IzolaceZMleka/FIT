package selenium;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.*;

public class GoogleSearch {

    WebDriver driver;

    /**
     * Open browser Firefox
     */
    @Before
    public void initBrowser() {
        driver = new FirefoxDriver();
    }

    /**
     * Close browser
     */
    @After
    public void closeDriver() {
        if (driver != null) {
            driver.close();
            driver = null;
        }
    }

    @Test
    public void search() {
        String page = "https://www.google.com";
        // load page Google
        driver.get(page);
        // find input element and set value
        driver.findElement(By.id("lst-ib")).sendKeys("Facebook");
        // find button and send form
        driver.findElement(By.xpath("//input[@name='btnK']")).click();

        // check redirect
        if (driver.getCurrentUrl().equals(page))
            fail("not redirected");
        else
            assertTrue(true);
    }
}
