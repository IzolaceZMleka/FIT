package othello2015.game;

import othello2015.board.Field;
import othello2015.board.Rules;

public class ReversiRules implements Rules
{

    private final int size;

    public ReversiRules(int size) {
        this.size = size;
    }

    public Field createField(int row, int col) {
        return new BoardField(row, col);
    }


    public int getSize() {
        return size;
    }


    public int numberDisks() {
        return (size * size) / 2;
    }

}
