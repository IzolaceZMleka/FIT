package othello2015.board;

import org.junit.Test;

import static org.junit.Assert.*;

public class DiskTest {
    @Test
    public void isWhite() {
        Disk d1 = new Disk(true);
        Disk d2 = new Disk(false);

        assertTrue(d1.isWhite());
        assertFalse(d2.isWhite());
    }

    @Test
    public void turn() {
        Disk d1 = new Disk(true);
        Disk d2 = new Disk(false);

        assertTrue(d1.isWhite());
        assertFalse(d2.isWhite());

        d1.turn();
        d2.turn();

        assertFalse(d1.isWhite());
        assertTrue(d2.isWhite());
    }

}