package othello2015;

import org.junit.Test;
import othello2015.board.Board;
import othello2015.board.Field;
import othello2015.game.Game;
import othello2015.game.Player;
import othello2015.game.ReversiRules;

import static org.junit.Assert.*;

public class ITGameTest {

    @Test
    public void initGame() {
        int size = 8;

        ReversiRules rules = new ReversiRules(size);
        Board board = new Board(rules);
        Game game = new Game(board);

        Player p1 = new Player(true);
        Player p2 = new Player(false);

        game.addPlayer(p1);
        game.addPlayer(p2);

        assertEquals("Test, zda je aktualni hrac bily.", p1, game.currentPlayer());
        assertTrue("Test spravneho umisteni pocatecnich kamenu.",
                game.getBoard().getField(4, 4).getDisk().isWhite());
        assertTrue("Test spravneho umisteni pocatecnich kamenu.",
                game.getBoard().getField(5, 5).getDisk().isWhite());
        assertFalse("Test spravneho umisteni pocatecnich kamenu.",
                game.getBoard().getField(4, 5).getDisk().isWhite());
        assertFalse("Test spravneho umisteni pocatecnich kamenu.",
                game.getBoard().getField(5, 4).getDisk().isWhite());

        Field f1 = game.getBoard().getField(3, 4);
        Field f2 = game.getBoard().getField(4, 6);
        assertFalse("Test umisteni kamene na spatnou pozici.", game.currentPlayer().canPutDisk(f1));
        assertTrue("Test umisteni kamene na dobrou pozici.", game.currentPlayer().canPutDisk(f2));
        assertTrue("Umisteni kamene.", game.currentPlayer().putDisk(f2));

        for (int i = 4; i <= 6; i++) {
            assertTrue("Test spravne barvy kamene.",
                    game.getBoard().getField(4, i).getDisk().isWhite());
        }

        game.nextPlayer();
        assertEquals("Test, zda je aktualni hrac cerny.", p2, game.currentPlayer());

        f2 = game.getBoard().getField(5, 6);
        assertTrue("Test umisteni kamene na dobrou pozici.", game.currentPlayer().canPutDisk(f2));
        assertTrue("Umisteni kamene.", game.currentPlayer().putDisk(f2));

        for (int i = 4; i <= 6; i++) {
            assertFalse("Test spravne barvy kamene.",
                    game.getBoard().getField(5, i).getDisk().isWhite());
        }
    }
}
