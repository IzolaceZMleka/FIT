package example.jsf.listener;

import javax.faces.event.*;
import example.jsf.bean.Language;
import static example.jsf.utils.BeanUtils.getBean;

/**
 *
 * @author Filip Pobořil
 */
public class LanguageChangeListener implements ValueChangeListener {

    @Override
    public void processValueChange(ValueChangeEvent event)
            throws AbortProcessingException {
        Language languageBean = (Language) getBean("language");
        languageBean.setSelected(event.getNewValue().toString());
    }

}
