package othello2015.game;

import othello2015.board.Board;
import othello2015.board.Disk;
import othello2015.board.Field;

public class Player
{

    private final boolean isWhite;
    private int countOfDisk = 0;

    public Player(boolean isWhite) {
        this.isWhite = isWhite;
    }

    public boolean canPutDisk(Field field) {
        boolean canPut = false;
        if (field.getDisk() == null) {
            for (Field.Direction c : Field.Direction.values()) {
                canPut = canPut || this.canPutDiskDirs(c, field.nextField(c), this.isWhite);
                if (canPut) {
                    break;
                }
            }
        }
        return canPut;
    }

    private boolean canPutDiskDirs(Field.Direction dirs, Field field, boolean isWhiteDisk) {
        int length = 1;
        while (true) {
            if (field.getDisk() == null) {
                return (false);
            }
            switch (length) {
                case 1:
                    if (field.getDisk().isWhite() == isWhiteDisk) {
                        return (false);
                    }
                    break;
                default:
                    if (field.getDisk().isWhite() == isWhiteDisk) {
                        return (true);
                    }
                    break;
            }
            length++;
            field = field.nextField(dirs);
        }
    }

    public boolean emptyPool() {
        return countOfDisk == 0;
    }

    public void init(Board board) {
        this.countOfDisk = board.getNumberDisks() - 2;
        int center = board.getSize() / 2;
        if (this.isWhite) {
            board.getField(center, center).putDisk(new Disk(true));
            board.getField(center + 1, center + 1).putDisk(new Disk(true));
        } else {
            board.getField(center + 1, center).putDisk(new Disk(false));
            board.getField(center, center + 1).putDisk(new Disk(false));
        }
    }

    public boolean isWhite() {
        return isWhite;
    }

    public boolean putDisk(Field field) {
        boolean canPut = false;
        if (field.getDisk() == null) {
            for (Field.Direction c : Field.Direction.values()) {
                canPut = canPut || this.putDiskDirs(c, field.nextField(c), 1);
            }
            if (canPut) {
                field.putDisk(new Disk(isWhite));
                this.countOfDisk--;
            }
        }
        return canPut;
    }

    private boolean putDiskDirs(Field.Direction dirs, Field field, int length) {
        boolean canPut = false;
        if (field.getDisk() != null) {
            if ((length == 1) && (field.getDisk().isWhite() != this.isWhite)) {
                canPut = this.putDiskDirs(dirs, field.nextField(dirs), length + 1);
            } else if (length > 1) {
                if (field.getDisk().isWhite() == this.isWhite) {
                    return (true);
                }
                canPut = this.putDiskDirs(dirs, field.nextField(dirs), length + 1);
            }
        }
        if (canPut) {
            field.getDisk().turn();
        }
        return canPut;
    }

    @Override
    public String toString() {
        return (isWhite) ? "white" : "black";
    }
}
