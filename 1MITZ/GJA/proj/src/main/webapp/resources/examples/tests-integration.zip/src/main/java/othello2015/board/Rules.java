package othello2015.board;

public interface Rules
{

    /**
     * Vytvoří pole na daném řádku a sloupci
     *
     * @param row
     * @param col
     * @return vytvořené pole
     */
    public Field createField(int row, int col);

    /**
     * Velikost hrací desky
     *
     * @return
     */
    public int getSize();

    /**
     * Počet disků, který má hráč k dispozici
     *
     * @return
     */
    public int numberDisks();
}
