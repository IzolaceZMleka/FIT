package othello2015.game;

import org.junit.Test;

import static org.junit.Assert.*;

public class ReversiRulesTest {

    @Test
    public void getSize() {
        ReversiRules rules = new ReversiRules(8);
        assertEquals(8, rules.getSize());
    }

    @Test
    public void numberDisks() {
        ReversiRules rules = new ReversiRules(8);
        assertEquals(8 * 8 / 2, rules.numberDisks());
    }

}