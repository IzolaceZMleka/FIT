package othello2015;

import org.junit.Before;
import org.junit.Test;
import othello2015.board.Board;
import othello2015.board.Field;
import othello2015.game.ReversiRules;

import static org.junit.Assert.*;

/**
 * Testovaní integrace mezi třídami game.ReversiRules a board.Board
 */
public class ITBoardReversiRulesTest {
    public int size = 8;
    public Board board;

    @Before
    public void initBoard() {
        ReversiRules rules = new ReversiRules(size);
        board = new Board(rules);
    }

    @Test
    public void getField() {
        Field f1 = board.getField(2, 3);
        Field f2 = board.getField(2, 3);
        Field f3 = board.getField(0, 0);

        assertEquals("Test shody dvou stejnych poli.", f1, f2);
        assertNotEquals("Test neshody dvou ruznych poli.", f1, f3);
    }

    @Test
    public void getSize() {
        assertEquals(size, board.getSize());
    }

}