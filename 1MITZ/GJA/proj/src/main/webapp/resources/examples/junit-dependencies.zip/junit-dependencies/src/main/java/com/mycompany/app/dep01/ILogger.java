package com.mycompany.app.dep01;

public interface ILogger {
    /**
     * Zaznamená nějakou zprávu
     *
     * @param message Zpráva k zaznamenání
     */
    public void log(String message);

    /**
     * Ověří jestli zapnutý mod pro výpis zpráv na stdout
     *
     * @return
     */
    public boolean isEnabledStdOutMode();

    /**
     * Ověří jestli je zapnutý režim pro ukládání zpráv do souboru
     *
     * @return
     */
    public boolean isEnabledFileMode();
}
