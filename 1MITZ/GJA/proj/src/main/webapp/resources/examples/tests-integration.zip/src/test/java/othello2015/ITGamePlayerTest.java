package othello2015;

import org.junit.Before;
import org.junit.Test;
import othello2015.board.Board;
import othello2015.game.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Testování propojení mezi třídami Player a Game
 */
public class ITGamePlayerTest {
    public int size = 8;
    public Game game;

    @Before
    public void initGame() {
        ReversiRules rules = new ReversiRules(size);
        Board board = new Board(rules);
        game = new Game(board);
    }

    @Test
    public void addPlayer() {
        Player p1 = new Player(true);
        Player p2 = new Player(false);
        Player p3 = new Player(true);

        assertTrue(game.addPlayer(p1));
        assertTrue(game.addPlayer(p2));

        assertFalse("Test neprazdne sady kamenu.", p1.emptyPool());
        assertFalse("Test neprazdne sady kamenu.", p1.emptyPool());

        assertFalse("Hra je pouze pro dva hráče", game.addPlayer(p3));
    }

    @Test
    public void currentPlayer() {
        Player p1 = new Player(true);
        Player p2 = new Player(false);

        game.addPlayer(p1);
        game.addPlayer(p2);

        assertSame(p1,game.currentPlayer());
        game.nextPlayer();
        assertSame(p2,game.currentPlayer());
        game.nextPlayer();
        assertSame(p1,game.currentPlayer());
    }

}
