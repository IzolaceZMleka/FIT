package othello2015;

import org.junit.Test;
import othello2015.board.Field;
import othello2015.game.ReversiRules;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Testostování integrace mezi třídami game.ReversRules a board.AbstractBoardField
 */
public class ITReversiRulesTest {

    @Test
    public void testRules()
    {
        int size = 8;

        ReversiRules rules = new ReversiRules(size);

        Field f1 = rules.createField(2, 3);
        Field f2 = rules.createField(2, 3);
        Field f3 = rules.createField(4, 4);

        assertEquals("Test shody dvou stejnych poli.", f1, f2);
        assertNotEquals("Test neshody dvou ruznych poli.", f1, f3);
    }
}
