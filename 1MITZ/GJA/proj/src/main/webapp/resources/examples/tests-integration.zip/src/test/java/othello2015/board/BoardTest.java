package othello2015.board;

import org.junit.Test;

import static org.junit.Assert.*;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

public class BoardTest {

    @Test
    public void getSize() {
        Rules rules = mock(Rules.class);
        Field field = mock(Field.class);
        when(rules.getSize()).thenReturn(8);
        when(rules.createField(anyInt(), anyInt())).thenReturn(field);

        Board board = new Board(rules);
        assertEquals(8, board.getSize());
    }

}