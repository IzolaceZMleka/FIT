package othello2015.game;

import othello2015.board.Board;

public class Game
{

    private final Board board;
    private Player firstPlayer = null;
    private Player secondPlayer = null;
    private boolean currentPlayer = true; // true - firstPlayer

    public Game(Board board) {
        this.board = board;
    }

    public boolean addPlayer(Player player) {
        if (firstPlayer != null) {
            if (firstPlayer.isWhite() == player.isWhite()) {
                return false;
            }
        } else if (secondPlayer != null) {
            if (secondPlayer.isWhite() == player.isWhite()) {
                return false;
            }
        }

        if (firstPlayer == null) {
            firstPlayer = player;
        } else if (secondPlayer == null) {
            secondPlayer = player;
        } else {
            return false;
        }
        player.init(board);
        return true;
    }

    public Player currentPlayer(){
        return currentPlayer ? firstPlayer: secondPlayer;
    }

    public Player nextPlayer() {
        this.currentPlayer = !currentPlayer;
        return currentPlayer();
    }

    public Board getBoard() {
        return board;
    }

}
