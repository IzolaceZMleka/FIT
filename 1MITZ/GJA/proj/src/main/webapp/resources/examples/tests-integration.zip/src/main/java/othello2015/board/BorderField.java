package othello2015.board;

/**
 * Okrajový disk
 */
public class BorderField implements Field
{

    public BorderField() {
    }

    public void addNextField(Direction dirs, Field field) {
    }

    public Disk getDisk() {
        return null;
    }

    public Field nextField(Direction dirs) {
        return null;
    }

    public boolean putDisk(Disk disk) {
        return false;
    }

    public boolean canPutDisk(Disk disk) {
        return false;
    }

}
