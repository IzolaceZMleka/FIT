package othello2015.board;

public class Disk
{

    private boolean isWhiteColor;

    public Disk(boolean isWhite) {
        isWhiteColor = isWhite;
    }

    public boolean isWhite() {
        return isWhiteColor;
    }

    public void turn() {
        if (isWhiteColor) {
            isWhiteColor = false;
        } else {
            isWhiteColor = true;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if ((obj != null) && (obj instanceof Disk) && (this.getClass() == obj.getClass())) {
            final Disk other = (Disk) obj;
            if (other.isWhiteColor == isWhiteColor) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int hashCode() {
        return super.hashCode(); //To change body of generated methods, choose Tools | Templates.
    }

}
