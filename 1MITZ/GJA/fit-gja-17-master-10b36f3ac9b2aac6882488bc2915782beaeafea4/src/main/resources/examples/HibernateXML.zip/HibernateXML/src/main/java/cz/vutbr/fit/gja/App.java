package cz.vutbr.fit.gja;

import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class App {
    public static void main(String[] args) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        String stringQuery = "DELETE FROM Book";
        Query query = session.createQuery(stringQuery);
        query.executeUpdate();

        Book book1 = new Book(123, "A House for Mr. Biswas", "V. S. Naipaul" , "novel",1);
        Book book2 = new Book(1245, "A Tale for the Time Being", "Ruth Ozeki" , "comedy",4);
        Book book3 = new Book(13454654, "The Wisdom of No Escape", "Pema Chödrön " , "drana",2);

        session.save(book1);
        session.save(book2);
        session.save(book3);
        session.getTransaction().commit();

        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            List books = session.createQuery("FROM Book").list();
            for (Iterator iterator = books.iterator(); iterator.hasNext();) {
                Book book = (Book) iterator.next();
                System.out.print("Title: " + book.getTitle());
                System.out.print("  Author: " + book.getAuthor());
                System.out.print("  Genre: " + book.getGenre());
                System.out.println("  Edition: " + book.getEdition());
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        }

        session.close();

    }
}
