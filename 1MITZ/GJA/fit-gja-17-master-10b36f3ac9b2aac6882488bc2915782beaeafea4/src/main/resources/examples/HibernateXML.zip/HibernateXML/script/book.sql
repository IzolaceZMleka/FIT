CREATE TABLE IF NOT EXISTS `BOOK` (
  `isbn` int(13) NOT NULL auto_increment,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `edition` int(11) NOT NULL,
  PRIMARY KEY (`isbn`)
);
