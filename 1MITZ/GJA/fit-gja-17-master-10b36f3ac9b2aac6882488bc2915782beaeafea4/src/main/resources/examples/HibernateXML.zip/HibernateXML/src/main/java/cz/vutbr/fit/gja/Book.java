package cz.vutbr.fit.gja;

public class Book {

    private int isbn;
    private String title;
    private String author;
    private String genre;
    private int edition;

    public Book(){
    }


    public Book(int isbn, String title, String author, String genre, int edition) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.edition = edition;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }
}
