package com.mycompany.app.basic;

import junit.framework.TestCase;

public class CalculatorTest extends TestCase {
    public Calculator calculator = null;

    /**
     * Provede se před každým testem
     */
    public void setUp() {
        calculator = new Calculator(1.0);
    }

    public void testSum() {
        calculator.sum(2.5);
        assertEquals(3.5, calculator.getResult());
    }

    public void testDivide() {
        try {
            calculator.divide(2.0);
            assertEquals(0.5, calculator.getResult());
        } catch (IllegalArgumentException e) {
            // nesmí nastat chyba při dělení (nedělíme nulou)
            fail(e.getMessage());
        }
    }

    public void testDivideByZero() {
        try {
           calculator.divide(0.0);
           fail("Nelze dělit nulou");
        } catch (IllegalArgumentException e) {
            assertEquals("Argument 'divide' is zero", e.getMessage());
        }
    }

    public void testMulticaption() {
        calculator.multicaption(25.0);
        assertEquals(25.0, calculator.getResult());
    }

    /**
     * Příklad (10.5 - 15.5) * 4 / 50
     */
    public void testExample01() {
        Calculator obj = new Calculator(10.5);
        try {
            obj.sum(-15.5)
                    .multicaption(4.0)
                    .divide(50.0);
            assertEquals(-0.4, obj.getResult());
        } catch (IllegalArgumentException e) {
            fail(e.getMessage());
        }
    }

    public void testEqual() {
        Calculator obj = new Calculator(1.0);
        assertTrue(calculator.equals(obj));
        assertTrue(obj.equals(calculator));
        assertTrue(obj.equals(new Double(1)));
    }

    public void testEqualFail() {
        Calculator obj = new Calculator(1.2);
        assertFalse(calculator.equals(obj));
        assertFalse(obj.equals(calculator));
        assertFalse(obj.equals(new Double(300)));
    }

}
