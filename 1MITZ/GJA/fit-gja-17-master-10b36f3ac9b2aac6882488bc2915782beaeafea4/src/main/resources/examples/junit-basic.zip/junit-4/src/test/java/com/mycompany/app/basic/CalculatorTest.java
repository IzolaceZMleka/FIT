package com.mycompany.app.basic;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.*;

public class CalculatorTest {

    public Calculator calculator;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setCalculator() {
        calculator = new Calculator(1.0);
    }

    @Test
    public void sum() {
        calculator.sum(2.5);
        assertEquals(new Double(3.5), new Double(calculator.getResult()));
    }

    @Test
    public void divide() {
        try {
            calculator.divide(2.0);
            assertEquals(new Double(0.5), new Double(calculator.getResult()));
        } catch (IllegalArgumentException e) {
            // nesmí nastat chyba při dělení (nedělíme nulou)
            fail(e.getMessage());
        }
    }

    /**
     * Způsob z JUnit 3.X je stále použitelný
     */
    @Test
    public void divideByZero() {
        try {
            calculator.divide(0.0);
            fail("Nelze dělit nulou");
        } catch (IllegalArgumentException e) {
            assertEquals("Argument 'divide' is zero", e.getMessage());
        }
    }

    /**
     * Nový způsob dostupný od verze 4
     */
    @Test
    public void divideByZeroNew() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("Argument 'divide' is zero");
        calculator.divide(0.0);
        fail("Nelze dělit nulou");
    }

    /**
     * Další způsob dostupný od verze 4
     */
    @Test(expected = IllegalArgumentException.class)
    public void divideByZeroNew2() {
        calculator.divide(0.0);
        fail("Nelze dělit nulou");
    }

    @Test
    public void multicaption() {
        calculator.multicaption(25.0);
        assertEquals(new Double(25.0), new Double(calculator.getResult()));
    }

    /**
     * Příklad (10.5 - 15.5) * 4 / 50
     */
    @Test
    public void example01() {
        Calculator obj = new Calculator(10.5);
        try {
            obj.sum(-15.5)
                    .multicaption(4.0)
                    .divide(50.0);
            assertEquals(new Double(-0.4), new Double(obj.getResult()));
        } catch (IllegalArgumentException e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void equals() throws Exception {
        Calculator obj = new Calculator(1.0);
        assertTrue(calculator.equals(obj));
        assertTrue(obj.equals(calculator));
        assertTrue(obj.equals(new Double(1)));
    }
}