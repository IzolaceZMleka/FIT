package com.mycompany.app.basic;

/**
 * Jednoduchá kalkulačka
 */
public class Calculator {
    /**
     * Výsledek výpočtu
     */
    private double result = 0.0;

    public Calculator() {}

    public Calculator(double result) {
        this.result = result;
    }

    /**
     * Přičte k předchozímu výsledku hodnotu sum
     *
     * @param sum
     * @return
     */
    public Calculator sum(double sum) {
        result += sum;
        return this;
    }

    /**
     * Předchozí výsledek vydělí hodnotou divide
     *
     * @param divide
     * @return
     */
    public Calculator divide(double divide) throws IllegalArgumentException {
        if (divide == 0.0)
            throw new IllegalArgumentException("Argument 'divide' is zero");
        result /= divide;
        return this;
    }

    /**
     * Přechozí výsledek vynásobí hodnotou multicaption
     *
     * @param multication
     * @return
     */
    public Calculator multicaption(double multication) {
        result *= multication;
        return this;
    }

    /**
     * Získá výsledek
     * @return
     */
    public double getResult() {
        return result;
    }

    @Override
    public String toString() {
        Double temp = new Double(result);
        return temp.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        if (o.getClass() == Double.class) {
            Double temp = new Double(result);
            return o.equals(temp);
        }
        if (getClass() != o.getClass()) return false;

        Calculator that = (Calculator) o;

        return Double.compare(that.getResult(), getResult()) == 0;
    }

    @Override
    public int hashCode() {
        long temp = Double.doubleToLongBits(getResult());
        return (int) (temp ^ (temp >>> 32));
    }
}
