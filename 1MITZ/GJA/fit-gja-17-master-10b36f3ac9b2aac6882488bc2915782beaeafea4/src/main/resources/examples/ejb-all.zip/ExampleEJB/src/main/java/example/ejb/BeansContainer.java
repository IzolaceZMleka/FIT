package example.ejb;

import javax.inject.Named;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;

/**
 * This is just JSF ManagedBean which is used to pass EJB instances to JSF.
 *
 * @author Filip Pobořil
 */
@Named(value = "beansContainer")
@SessionScoped
public class BeansContainer implements Serializable {

    @EJB(lookup = "java:global/ExampleEJB-1.0/AccountBean")
    private AccountRemoteIface account;
    @EJB(lookup = "java:global/ExampleEJB-1.0/CalculatorBean")
    private CalculatorRemoteIface calculator;

    public AccountRemoteIface getAccount() {
        return account;
    }

    public CalculatorRemoteIface getCalculator() {
        return calculator;
    }

}
