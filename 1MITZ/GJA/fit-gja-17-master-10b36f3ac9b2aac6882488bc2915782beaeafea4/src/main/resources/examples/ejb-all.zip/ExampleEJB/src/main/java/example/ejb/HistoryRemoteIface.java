package example.ejb;

import java.util.List;
import javax.ejb.Remote;

/**
 * @author Filip Pobořil
 */
@Remote
public interface HistoryRemoteIface {

    public void push(String url);

    public String pop();

    public List<String> getHistory();

}
