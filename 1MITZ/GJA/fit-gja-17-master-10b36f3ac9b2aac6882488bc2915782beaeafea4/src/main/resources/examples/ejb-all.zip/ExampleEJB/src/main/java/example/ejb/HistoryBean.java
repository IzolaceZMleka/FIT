package example.ejb;

import java.util.List;
import java.util.Stack;
import javax.annotation.PreDestroy;
import javax.ejb.Stateful;
import javax.interceptor.Interceptors;

/**
 *
 * @author Filip Pobořil
 */
@Stateful
@Interceptors({HistoryInterceptor.class})
public class HistoryBean implements HistoryRemoteIface {

    private Stack<String> history;

    public HistoryBean() {
        history = new Stack<>();
    }

    @Override
    public void push(String url) {
        history.push(url);
    }

    @Override
    public String pop() {
        return history.pop();
    }

    @Override
    public List<String> getHistory() {
        return history;
    }

    @PreDestroy
    public void preDestroy() {
        System.out.println("PreDestroy invocation");
    }

}
