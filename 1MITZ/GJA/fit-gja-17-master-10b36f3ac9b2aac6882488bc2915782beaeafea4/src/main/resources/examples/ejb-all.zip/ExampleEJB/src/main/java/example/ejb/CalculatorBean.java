package example.ejb;

import javax.ejb.Stateless;

/**
 * Example stateless EJB (Enterprise Java Bean).
 *
 * Stateless beans should not contain any instance variables because their
 * content is not guaranteed to be preseverved across method calls.
 *
 * Typical usage may be sending an email.
 *
 * @author Filip Pobořil
 */
@Stateless
public class CalculatorBean implements CalculatorRemoteIface {

    @Override
    public int add(int lft, int rgh) {
        return lft + rgh;
    }

    @Override
    public int sub(int lft, int rgh) {
        return lft - rgh;
    }

}
