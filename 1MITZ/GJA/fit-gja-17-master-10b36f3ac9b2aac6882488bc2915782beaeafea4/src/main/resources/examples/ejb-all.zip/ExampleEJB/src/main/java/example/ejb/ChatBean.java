package example.ejb;

import javax.annotation.Resource;
import javax.ejb.MessageDriven;
import javax.jms.*;

/**
 * @author Filip Pobořil
 */
//@MessageDriven
public class ChatBean implements MessageListener {

    //@Resource
    private ConnectionFactory connectionFactory;
    //@Resource(name = "ChatQueue")
    private Queue chatQueue;

    public ChatBean() {
    }

    @Override
    public void onMessage(Message message) {
        try {
            final String text = ((TextMessage) message).getText();
            send("Reply to '" + text + "'");
        } catch (JMSException ex) {
            // empty...
        }
    }

    private void send(String text) throws JMSException {
        try (Connection connection = connectionFactory.createConnection();
             Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE)) {
            connection.start();

            // Create a MessageProducer from the Session to the Topic or Queue
            MessageProducer producer = session.createProducer(chatQueue);
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            // Create a message
            TextMessage message = session.createTextMessage(text);

            // Tell the producer to send the message
            producer.send(message);
        }
    }
}
