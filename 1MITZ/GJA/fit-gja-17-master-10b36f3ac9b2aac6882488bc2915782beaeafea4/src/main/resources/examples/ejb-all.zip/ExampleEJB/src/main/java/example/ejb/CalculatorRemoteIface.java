package example.ejb;

import javax.ejb.Remote;

/**
 * Remote interaface for EJB.
 *
 * @author Filip Pobořil
 */
@Remote
public interface CalculatorRemoteIface {

    public int add(int lft, int rgh);

    public int sub(int lft, int rgh);

}
