package example.ejb;

import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 * Interceptor class.
 *
 * @AroundInvoke specifies the business method interceptor method. You can use
 * this annotation only once in an interceptor class.
 *
 * @PostActivate and @PrePassivate annotations specify the methods that the EJB
 * container should call after reactivating and before passivating the bean,
 * respectively.
 *
 * @author Filip Pobořil
 */
public class HistoryInterceptor {

    @AroundInvoke
    public Object aroundInvoke(InvocationContext ic) throws Exception {
        System.out.println("AroundInvoke: Invoking method: " + ic.getMethod());
        return ic.proceed();
    }

    @PostActivate
    public void postActivate(InvocationContext ic) {
        System.out.println("PostActivate: Invoking method: " + ic.getMethod());
    }

    @PrePassivate
    public void prePassivate(InvocationContext ic) {
        System.out.println("PrePassivate: Invoking method: " + ic.getMethod());
    }

}
