package example.ejb;

import java.util.List;
import javax.ejb.Remote;
import javax.ejb.Remove;

/**
 * Remote interface for EJB.
 *
 * @author Filip Pobořil
 */
@Remote
public interface AccountRemoteIface {

    public int transaction(int amount);

    public int deposit(int amount);

    public int withdraw(int amount);

    @Remove
    public void remove();

    public int getBalance();

    public List<Integer> getTransactionHistory();

}
