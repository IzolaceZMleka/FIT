package example.ejb;

import java.util.LinkedList;
import java.util.List;
import javax.ejb.Remove;
import javax.ejb.Stateful;

/**
 * Example stateful EJB (Enterprise Java Bean).
 *
 * Stateful beans have state, they keep track of which calling client they are
 * dealing with throughout a session.
 *
 * @author Filip Pobořil
 */
@Stateful
public class AccountBean implements AccountRemoteIface {

    private int balance = 0;
    private List<Integer> transactionHistory;

    public AccountBean() {
        this.transactionHistory = new LinkedList<>();
    }

    @Override
    public int transaction(int amount) {
        transactionHistory.add(amount);
        balance += amount;
        return balance;
    }

    @Override
    public int deposit(int amount) {
        return transaction(amount);
    }

    @Override
    public int withdraw(int amount) {
        return transaction(-amount);
    }

    /**
     * Indicate to the container that the stateful session bean is to be removed
     * by the container after completion of the method.
     */
    @Remove
    @Override
    public void remove() {
        balance = 0;
        transactionHistory.clear();
    }

    @Override
    public int getBalance() {
        return balance;
    }

    @Override
    public List<Integer> getTransactionHistory() {
        return transactionHistory;
    }

}
