Just run script tests.sh after you finish modifying given stepX.
