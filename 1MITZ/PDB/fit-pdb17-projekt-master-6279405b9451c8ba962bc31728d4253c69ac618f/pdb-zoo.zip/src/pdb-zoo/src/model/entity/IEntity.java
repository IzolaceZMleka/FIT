package model.entity;

/**
 * Interface for DB Entities
 *
 * @author Ondřej Zemánek
 */
public interface IEntity {
}
